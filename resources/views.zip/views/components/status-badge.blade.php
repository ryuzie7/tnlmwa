<x-status-badge text="Approved" />
<x-status-badge text="Rejected" />
<x-status-badge text="Pending" />
<x-status-badge text="Deleted" />
