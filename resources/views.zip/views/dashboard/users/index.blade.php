@extends('layouts.app')

@section('title', 'Users')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">Users</h1>

    @if(session('success'))
    <div class="bg-green-100 dark:bg-green-800 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-100 px-4 py-3 rounded mb-4 shadow-sm">
        <i class="fas fa-check-circle mr-2"></i>{{ session('success') }}
    </div>
    @endif

    @if(session('error'))
    <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-100 px-4 py-3 rounded mb-4 shadow-sm">
        <i class="fas fa-exclamation-circle mr-2"></i>{{ session('error') }}
    </div>
    @endif

    <div class="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow-sm">
        <table class="min-w-full text-sm text-left text-gray-800 dark:text-gray-200 divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-100 dark:bg-gray-700 text-xs uppercase text-gray-600 dark:text-gray-300 tracking-wider">
                <tr>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3">Phone</th>
                    <th class="px-4 py-3">Staff ID</th>
                    <th class="px-4 py-3">Status</th>
                    @if(auth()->user()->role === 'admin')
                        <th class="px-4 py-3 text-center">Actions</th>
                    @endif
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                @forelse($users as $user)
                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td class="px-4 py-3">{{ $user->name }}</td>
                    <td class="px-4 py-3">{{ $user->email }}</td>
                    <td class="px-4 py-3">{{ $user->phone }}</td>
                    <td class="px-4 py-3">{{ $user->staff_id }}</td>
                    <td class="px-4 py-3">
    @if($user->email_verified_at)
        <span class="bg-green-600 text-white text-xs px-2 py-1 rounded font-medium">Verified</span>
    @else
        <span class="bg-red-500 text-white text-xs px-2 py-1 rounded font-medium">Not Verified</span>
    @endif
</td>


                    @if(auth()->user()->role === 'admin')
                    <td class="px-4 py-3 text-center space-x-2">
                        @if($user->approved === false)
                        <form action="{{ route('users.approve', $user) }}" method="POST" class="inline-block">
                            @csrf
                            <button type="submit" class="text-green-600 hover:text-green-800 dark:hover:text-green-400 font-medium text-sm" onclick="return confirm('Approve this user?')">
                                <i class="fas fa-check mr-1"></i>Approve
                            </button>
                        </form>
                        <form action="{{ route('users.reject', $user) }}" method="POST" class="inline-block ml-1">
                            @csrf
                            <button type="submit" class="text-red-600 hover:text-red-800 dark:hover:text-red-400 font-medium text-sm" onclick="return confirm('Reject this user?')">
                                <i class="fas fa-times mr-1"></i>Reject
                            </button>
                        </form>
                        @else
                        <span class="text-gray-500 dark:text-gray-400 text-sm">No actions available</span>
                        @endif
                    </td>
                    @endif
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="text-center text-gray-500 dark:text-gray-300 py-6">No users found.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
