@extends('layouts.app')

@section('title', 'Pending Asset Requests')

@section('content')
<div class="container py-6">
    <h1 class="text-2xl font-semibold text-gray-800 dark:text-white mb-4">Pending Asset Requests</h1>

    @if(session('success'))
        <div class="bg-green-100 dark:bg-green-800 text-green-700 dark:text-green-100 border border-green-400 dark:border-green-600 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('info'))
        <div class="bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-100 border border-blue-400 dark:border-blue-600 px-4 py-3 rounded mb-4">
            {{ session('info') }}
        </div>
    @endif

    <div class="overflow-x-auto bg-white dark:bg-gray-800 shadow rounded-lg">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 text-sm text-gray-800 dark:text-gray-100">
            <thead class="bg-gray-100 dark:bg-gray-700 text-xs uppercase font-semibold">
                <tr>
                    <th class="px-4 py-2">User</th>
                    <th class="px-4 py-2">Type</th>
                    <th class="px-4 py-2">Brand</th>
                    <th class="px-4 py-2">Model</th>
                    <th class="px-4 py-2">Location</th>
                    <th class="px-4 py-2">Requested At</th>
                    <th class="px-4 py-2">Notes</th>
                    <th class="px-4 py-2 text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse($requests as $request)
                    <tr class="border-t dark:border-gray-700">
                        <td class="px-4 py-2">{{ $request->user->name }}</td>
                        <td class="px-4 py-2">{{ ucfirst($request->action) }}</td>
                        <td class="px-4 py-2">{{ $request->brand }}</td>
                        <td class="px-4 py-2">{{ $request->model }}</td>
                        <td class="px-4 py-2">{{ $request->location }}</td>
                        <td class="px-4 py-2">{{ $request->requested_at->format('M d, Y H:i') }}</td>
                        <td class="px-4 py-2">{{ \Illuminate\Support\Str::limit($request->notes, 40, '...') ?? '-' }}</td>
                        <td class="px-4 py-2 text-center">
                            <form action="{{ route('assets.requests.approve', $request) }}" method="POST" class="inline-block">
                                @csrf
                                <button type="submit" class="text-green-600 hover:text-green-800 dark:hover:text-green-400" onclick="return confirm('Approve this request?')">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                            <form action="{{ route('assets.requests.reject', $request) }}" method="POST" class="inline-block ml-2">
                                @csrf
                                <button type="submit" class="text-red-600 hover:text-red-800 dark:hover:text-red-400" onclick="return confirm('Reject this request?')">
                                    <i class="fas fa-times"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="8" class="text-center text-gray-500 dark:text-gray-300 py-6">No pending requests found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($requests->hasPages())
        <div class="mt-6">
            {{ $requests->links() }}
        </div>
    @endif
</div>
@endsection
