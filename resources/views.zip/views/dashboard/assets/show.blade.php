@extends('layouts.app')

@section('title', 'Asset Details')

@section('content')
<div class="max-w-4xl mx-auto py-6 px-4 bg-white dark:bg-gray-800 rounded shadow">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white">Asset Details</h2>
            <p class="text-gray-500 dark:text-gray-300">Detailed view of asset {{ $asset->property_number }}</p>
        </div>
        <a href="{{ route('assets.index') }}" class="text-blue-600 hover:underline dark:text-blue-400">
            <i class="fas fa-arrow-left mr-1"></i> Back to Assets
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-gray-800 dark:text-gray-200">
        <div>
            <div class="mb-4"><strong>Property Number:</strong><br>{{ $asset->property_number }}</div>
            <div class="mb-4"><strong>Brand:</strong><br>{{ $asset->brand }}</div>
            <div class="mb-4"><strong>Model:</strong><br>{{ $asset->model }}</div>
            <div class="mb-4"><strong>Type:</strong><br>{{ $asset->type }}</div>
            <div class="mb-4"><strong>Condition:</strong><br>{{ $asset->condition }}</div>
        </div>
        <div>
            <div class="mb-4"><strong>Location:</strong><br>{{ $asset->location }}</div>
            <div class="mb-4"><strong>Building:</strong><br>{{ $asset->building_name }}</div>
            <div class="mb-4"><strong>Fund:</strong><br>{{ $asset->fund }}</div>
            <div class="mb-4"><strong>Year Acquired:</strong><br>{{ $asset->acquired_at }}</div>
            <div class="mb-4"><strong>Custodian:</strong><br>{{ $asset->custodian }}</div>
        </div>
    </div>

    <div class="mt-8 text-center">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-2">QR Code</h3>
        <div class="inline-block border p-4 bg-white rounded shadow dark:bg-gray-100">
            <img src="{{ route('assets.qr', $asset->id) }}" alt="QR for {{ $asset->property_number }}" class="mx-auto" width="200">
        </div>
        <div class="mt-4">
            <a href="{{ route('assets.qr.download', $asset->id) }}" target="_blank" class="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded inline-block">
                <i class="fas fa-download mr-1"></i> Download QR
            </a>
        </div>
    </div>

    @auth
    <div class="mt-6 text-right">
        <a href="{{ route('assets.edit', $asset) }}" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow">
            <i class="fas fa-edit mr-1"></i> Edit Asset
        </a>
    </div>
    @endauth
</div>
@endsection
