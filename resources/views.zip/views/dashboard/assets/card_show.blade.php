@extends('layouts.app')

@section('title', 'Asset Card View')

@section('content')
<div class="w-full px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">Asset Detail (Card View)</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <div class="grid md:grid-cols-2 gap-6">
            <div>
                <p><strong>Property Number:</strong> {{ $asset->property_number }}</p>
                <p><strong>Brand:</strong> {{ $asset->brand }}</p>
                <p><strong>Model:</strong> {{ $asset->model }}</p>
                <p><strong>Type:</strong> {{ $asset->type }}</p>
                <p><strong>Condition:</strong>
                    <span class="inline-block text-xs font-semibold px-2 py-1 rounded
                        {{ $asset->condition === 'Fair' ? 'bg-yellow-100 dark:bg-yellow-400 text-yellow-900' :
                           ($asset->condition === 'Poor' ? 'bg-red-100 dark:bg-red-600 text-red-900 dark:text-white' : 'bg-green-100 dark:bg-green-500 text-green-900') }}">
                        {{ $asset->condition }}
                    </span>
                </p>
                <p><strong>Location:</strong> {{ $asset->location }}</p>
            </div>
            <div>
                <p><strong>Building:</strong> {{ $asset->building_name }}</p>
                <p><strong>Fund:</strong> {{ $asset->fund }}</p>
                <p><strong>Price:</strong> {{ $asset->price !== null ? 'RM ' . number_format($asset->price, 2) : '-' }}</p>
                <p><strong>Year Acquired:</strong> {{ $asset->acquired_at ?? '-' }}</p>
                <p><strong>Previous Custodian:</strong> {{ $asset->previous_custodian }}</p>
                <p><strong>Custodian:</strong> {{ $asset->custodian }}</p>
            </div>
        </div>

        @if($asset->latitude && $asset->longitude)
        <div class="mt-6 text-right">
            <a href="https://www.google.com/maps/dir/?api=1&destination={{ $asset->latitude }},{{ $asset->longitude }}"
               target="_blank"
               class="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded shadow transition">
                <i class="fas fa-location-arrow mr-2"></i> Get Directions
            </a>
        </div>
        @endif

        @auth
        <div class="mt-4 text-right">
            <a href="{{ route('assets.edit', $asset) }}"
               class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow">
                <i class="fas fa-edit mr-1"></i> Edit Asset
            </a>
        </div>
        @endauth
    </div>
</div>
@endsection
