@extends('layouts.app')

@section('title', 'Asset QR Code')

@section('content')
<div class="max-w-xl mx-auto bg-white p-6 mt-10 rounded shadow">
    <h2 class="text-2xl font-semibold text-center mb-4">QR Code for Asset: {{ $asset->property_number }}</h2>

    <div class="flex justify-center mb-6">
        {!! $qrCode !!}
    </div>

    <div class="flex justify-center">
        <a href="{{ route('assets.qr.download', $asset) }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
            <i class="fas fa-download mr-1"></i> Download QR Code
        </a>
        <a href="{{ route('assets.index') }}" class="ml-4 bg-gray-300 hover:bg-gray-400 text-black px-4 py-2 rounded">
            <i class="fas fa-arrow-left mr-1"></i> Back to Assets
        </a>
    </div>
</div>
@endsection
