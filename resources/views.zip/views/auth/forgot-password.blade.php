<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600 dark:text-gray-400">
       Forgot your password? No problem. Just enter your verified email address and we will send you a secure password reset link.
    </div>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('password.email') }}" id="forgot-password-form">
        @csrf

        <!-- Email Address -->
        <div>
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autofocus />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Google Invisible reCAPTCHA -->
        <input type="hidden" name="g-recaptcha-response" id="g-recaptcha-response">

        <div class="flex items-center justify-end mt-4">
            <x-primary-button onclick="submitWithRecaptcha(event)">
                Email Password Reset Link
            </x-primary-button>
        </div>
    </form>

    @push('scripts')
        <script src="https://www.google.com/recaptcha/api.js?render={{ env('RECAPTCHA_SITE_KEY') }}"></script>
        <script>
            function submitWithRecaptcha(e) {
                e.preventDefault();
                grecaptcha.ready(function () {
                    grecaptcha.execute('{{ env('RECAPTCHA_SITE_KEY') }}', {action: 'submit'}).then(function (token) {
                        document.getElementById('g-recaptcha-response').value = token;
                        document.getElementById('forgot-password-form').submit();
                    });
                });
            }
        </script>
    @endpush
</x-guest-layout>
