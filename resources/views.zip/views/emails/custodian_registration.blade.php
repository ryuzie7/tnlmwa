<!DOCTYPE html>
<html>
<head>
    <title>New Custodian Registration</title>
</head>
<body>
    <h3>Dear Admin,</h3>
    <p>A new custodian has registered on the platform:</p>
    <p><strong>Name:</strong> {{ $custodianName }}</p>
    <p><strong>Email:</strong> {{ $custodianEmail }}</p>
    <p>Please log in to the admin panel to approve or reject this registration.</p>
</body>
</html>
